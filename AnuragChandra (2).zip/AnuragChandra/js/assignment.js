"use strict";

// functions

// Function to get the pointer to where the user has clicked 
function getMouseXY(e) {
  let canvas = document.getElementById('canvas_example');
  let boundingRect = canvas.getBoundingClientRect();
  let offsetX = boundingRect.left;
  let offsetY = boundingRect.top;
  let w = (boundingRect.width-canvas.width)/2;
  let h = (boundingRect.height-canvas.height)/2;
  offsetX += w;
  offsetY += h;
  // use clientX and clientY as getBoundingClientRect is used above
  let mx = Math.round(e.clientX-offsetX);
  let my = Math.round(e.clientY-offsetY);
  return {x: mx, y: my};
}

// Function to clear the canvas
function clearCanvas(context) {
  context.clearRect(0, 0, WIDTH, HEIGHT);
}

// Function to draw the initial image 
function drawImage(context) {
	clearCanvas(context);
	
	faceType = "Normal";
	hairStyle = "Normal";
	eyeStyle = "Normal";
	
	// These are all variables for different parts of the face(Helps in drawing the face) 
	var img = document.getElementById("hair");
	context.drawImage(img, 30, 20, 500, 250);
	
	img = document.getElementById("face");
	context.drawImage(img, 30, 120, 500, 400);
	
	img = document.getElementById("eye");
	context.drawImage(img, 110, 250, 100, 100);
	context.drawImage(img, 310, 250, 100, 100);
	
	img = document.getElementById("left_eyebrow");
	context.drawImage(img, 120, 200, 77, 75);
	img = document.getElementById("right_eyebrow");
	context.drawImage(img, 320, 200, 75, 75);
	
	img = document.getElementById("nose");
	context.drawImage(img, 220, 280, 100, 100)
	
	img = document.getElementById("mouth");
	context.drawImage(img, 220, 350, 100, 70)
	
	img = document.getElementById("left_ear");
	context.drawImage(img, 0, 190, 150, 150)
	
	img = document.getElementById("right_ear");
	context.drawImage(img, 380, 190, 150, 150)
}

// Function to draw normal face 
function drawNormalFace(context) {
		
	// If condition for the surprised face
	if (faceType == "Surprised") {
		var img = document.getElementById("mouth");

		// Change the Mouth to regular
		context.clearRect(220, 370, 120,60);
		context.drawImage(img, 220, 360, 100, 70);
		
		// Change to regular Eyes
		img = document.getElementById("eye");
		context.clearRect(110, 250, 100, 100);
		context.clearRect(310, 250, 100, 100);
		
		context.drawImage(img, 110, 250, 100, 50);
		context.drawImage(img, 310, 250, 100, 50);
		
		// Change FaceType to Normal again
		faceType = "Normal";
		eyeStyle = "Normal";
		
	  // Else if condition for the happy  face
	} else if (faceType == "Happy") {
		// Change Mouth to regular
		var img = document.getElementById("mouth");
		context.clearRect(220, 370, 120,60);
		context.drawImage(img, 220, 360, 100, 70);
		
		// Change to Regular Eyes
		img = document.getElementById("eye");
		context.clearRect(110, 250, 100, 100);
		context.clearRect(310, 250, 100, 100);
		
		context.drawImage(img, 110, 250, 100, 50);
		context.drawImage(img, 310, 250, 100, 50);
		
		// Change FaceType to Normal again
		faceType = "Normal";
		eyeStyle = "Normal";
	}
	
	
}

// Function to draw the surprised face 
function drawSurprisedFace(context) {
	
	faceType = "Surprised";
	
	var img = document.getElementById("surprised_mouth");
	context.clearRect(220, 370, 120,60);
	
	context.drawImage(img, 220, 360, 100, 70);
	
	// Change to Surprised Eyes
	img = document.getElementById("eye");
	context.clearRect(110, 260, 100, 100);
	context.clearRect(310, 260, 100, 100);
	
	context.drawImage(img, 110, 250, 100, 100);
	context.drawImage(img, 310, 250, 100, 100);
	
	eyeStyle = "Normal";
}


// Function to display the x,y location(Used only for debugging)
function displayResult(str) {
  debugger;
  let outputArea = document.getElementById('output_area');
  let myElement = document.createElement("p");
  let textNode = document.createTextNode(str);
  myElement.appendChild(textNode);
  if (outputArea.firstChild)
    outputArea.replaceChild(myElement, outputArea.firstChild);
  else
    outputArea.appendChild(myElement);
}

// Function to draw the happy face 
function drawHappyFace(context) {	
	faceType="Happy";
		
	// Change to Happy Mouth
	var img = document.getElementById("happy_mouth");
	context.clearRect(220, 370, 120,60);
	context.drawImage(img, 220, 360, 100, 70);
	
	// Change to Happy Eyes
	img = document.getElementById("happy_eye");
	context.clearRect(110, 250, 100, 100);
	context.clearRect(310, 250, 100, 100);
	
	context.drawImage(img, 110, 250, 100, 50);
	context.drawImage(img, 310, 250, 100, 50);
	
	eyeStyle = "Happy";
}

// Function to change the hairstyle 
function changeHairStyle(context) {	
	// Change Hair Style
	context.clearRect(30, 20, 500, 210);
	if (hairStyle == "Normal") {
		var img = document.getElementById("hair");
		context.drawImage(img, 30, 10, 500, 200);
	} else {
		var img = document.getElementById("hair_new");
		context.drawImage(img, 30, 10, 500, 200);
	}
}

// Function to add a beard 
function addBeard(context) {	
	// Add Beard
	
	if (beardStyle == "Normal") {
		context.clearRect(220,420, 100, 35);
		//var img = document.getElementById("beard");
		//context.drawImage(img, 190, 410, 175, 65);
	} else {
		var img = document.getElementById("beard");
		context.drawImage(img, 220, 420, 100, 35);
	}
}

// Function to take action when the user clicks on the chin or the hair 
function doSomething(evt) {
  let canvas = document.getElementById('canvas_example');
  let context = canvas.getContext('2d');
  let pos = getMouseXY(evt);
  let str = "x, y: "+pos.x+", "+pos.y;
  //displayResult(str);
  
  // Clicked on the hair
  if ((pos.x >=79) && (pos.x <=467) && (pos.y >=86) && (pos.y <= 200)) {
	  if (hairStyle=="Normal") {
		  hairStyle = "New";
	  }
	  else {
		  hairStyle="Normal";
	  }
	  
	  changeHairStyle(context);
  }
  
  // Clicked on the chin
  if ((pos.x >=220) && (pos.x <=318) && (pos.y >=420) && (pos.y <= 450)) {
	  if (beardStyle == "Normal") {
		  beardStyle = "New";
	  } else {
		  beardStyle = "Normal";
	  }
	  
	  addBeard(context);
  }

}

// main program body 

let canvas = document.getElementById('canvas_example');
let context = canvas.getContext('2d');
const WIDTH = canvas.width;
const HEIGHT = canvas.height;

let neutralButton = document.getElementById("neutralbutton");
let surpriseButton = document.getElementById("surprisedbutton");
let happyButton = document.getElementById("happybutton");

let faceType  = "Normal";
let hairStyle = "Normal";
let eyeStyle = "Normal";
let beardStyle = "Normal";

drawImage(context);

canvas.addEventListener('click', doSomething);

// With anonymous functions, the context can be passed as a parameter to each of the functions
neutralButton.addEventListener("click", function() { drawNormalFace(context) });
surpriseButton.addEventListener("click", function() { drawSurprisedFace(context) });
happyButton.addEventListener("click", function() { drawHappyFace(context) });